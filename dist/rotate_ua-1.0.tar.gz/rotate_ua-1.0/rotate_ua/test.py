#importing the UA package
import useragent
useragent.get_ua("web")
useragent.get_ua("mobile")